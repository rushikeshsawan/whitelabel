const Web3 = require('web3');
const Provider = require('@truffle/hdwallet-provider');
const MyContract = require('./SimpleStorage.json');
const address = '0x8e8Ef3E7D09D1fE0683f9B782860Bb00e41DE660';
const privateKey = '4925f96bd005d94c76b3646593aba2615f4b65b197160bdf96ce9a586d41067e';
const infuraUrl = 'https://ropsten.infura.io/v3/cecc686c7c684ee981dd2961d36d084c';
const crypto = require("crypto");
const express = require('express');
const router = express.Router();
var database = require('./database');
const bodyParser = require("body-parser");
const encoder = bodyParser.urlencoded();
const moment = require('moment');
var qr = require('qr-image');



async function getTotalsold() {
    if (address != null) {
  
  
        const provider = new Provider(privateKey, infuraUrl);
        const web3 = await new Web3(provider, { timeout: 3000000 });
        
    //   const id = await web3.eth.net.getId();
      // const deployednetwork = mycontract.networks[id];
      const networkId = await web3.eth.net.getId();

      const contract = new web3.eth.Contract(
        MyContract.abi,
        MyContract.networks[networkId].address
      );
      const addresses = web3.eth.getAccounts();
  
  
      let res1 = await contract.methods.getdata().send({ from: address,  }).then((res) => {
        console.log("result here" + JSON.stringify(res))}).catch((err) => {
        console.log("error here" + JSON.stringify(err));
    });      // console.log("total sold products are: " + result1);
      // const data= await web3.eth.getData().call();
      return await res1;
  
  
  
  
    } else {
      return "Please Connect Your Metamask";
    }
  
  
  }
  console.log(JSON.stringify(getTotalsold()));
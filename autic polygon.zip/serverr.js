const Web3 = require('web3');
const Provider = require('@truffle/hdwallet-provider');
const MyContract = require('./SimpleStorage.json');
const address = '0x8e8Ef3E7D09D1fE0683f9B782860Bb00e41DE660';
const conaddress= '0x25450a840B504cb1Bde85E61463e446F8890dDAB';
const privateKey = '4925f96bd005d94c76b3646593aba2615f4b65b197160bdf96ce9a586d41067e';
const infuraUrl = 'https://rpc-mumbai.maticvigil.com/v1/7bb20ca3fcfe0574153ff769c5fb5fd02fff93e3';
const crypto = require("crypto");
const express = require('express');
const router = express.Router();
var database = require('./database');
const bodyParser = require("body-parser");
const encoder = bodyParser.urlencoded();
const moment = require('moment');
var qr = require('qr-image');
const encrypt = (plainText, password) => {
  try {
    const iv = crypto.randomBytes(16);
    const key = crypto.createHash('sha256').update(password).digest('base64').substr(0, 32);
    const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
    let encrypted = cipher.update(plainText);
    encrypted = Buffer.concat([encrypted, cipher.final()])
    return iv.toString('hex') + '-' + encrypted.toString('hex');
  } catch (error) {
    console.log(error);
  }
}
const decrypt = (encryptedText, password) => {
  try {
    const textParts = encryptedText.split('-');
    const iv = Buffer.from(textParts.shift(), 'hex');
    const encryptedData = Buffer.from(textParts.join(':'), 'hex');
    const key = crypto.createHash('sha256').update(password).digest('base64').substr(0, 32);
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

    const decrypted = decipher.update(encryptedData);
    const decryptedText = Buffer.concat([decrypted, decipher.final()]);
    return decryptedText.toString();
  } catch (error) {
    console.log(error)
  }
}

//Hard way (web3#signTransaction() + web3#sendSignedTransaction())
const init1 = async () => {
    const web3 = new Web3(infuraUrl);
    const networkId = await web3.eth.net.getId();
    console.log(networkId);
    const myContract = new web3.eth.Contract(
        MyContract.abi,
        conaddress
        // MyContract.networks[networkId].address
    );

    const tx = myContract.methods.set_new_product(56454154, "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo");
    const gas = await tx.estimateGas({ from: address });
    const gasPrice = await web3.eth.getGasPrice();
    const data = tx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(address);

    const signedTx = await web3.eth.accounts.signTransaction(
        {
            to: myContract.options.address,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: networkId
        },
        privateKey
    );
    // console.log(`Old data value: ${await myContract.methods.data().call()}`);
    const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
    console.log(`Transaction hash: ${receipt.transactionHash}`);
    // console.log(`New data value: ${await myContract.methods.data().call()}`);
}

//Slightly easier (web3#sendTransaction())
// const init2 = async () => {
//     try{
//   const web3 = new Web3(infuraUrl);
//   const networkId = await web3.eth.net.getId();
//   const myContract = new web3.eth.Contract(
//     MyContract.abi,
//     MyContract.networks[networkId].address
//   );
//   web3.eth.accounts.wallet.add(privateKey);

//   const tx = myContract.methods.set_warranty(12345);
// //   const tx = myContract.methods.get_product_details(1234).call().then(result => { console.log(result) } );
//   const gas = await tx.estimateGas({from: address});
//   const gasPrice = await web3.eth.getGasPrice();
//   const data = tx.encodeABI();
//   const nonce = await web3.eth.getTransactionCount(address);
//   const txData = {
//     from: address,
//     to: myContract.options.address,
//     data: data,
//     gas,
//     gasPrice,
//     nonce, 
//   };

// //   console.log(`Old data value: ${await myContract.methods.data().call()}`);
//   const receipt = await web3.eth.sendTransaction(txData);
// //   console.log(`Transaction hash: ${receipt.transactionHash}`);
// //   console.log("success",tx);
// //   console.log(`New data value: ${await myContract.methods.data().call()}`);
// }catch(e){
//     // console.log(JSON.parse(e));
// console.error(e);
// }
// }

// Easy way (Web3 + @truffle/hdwallet-provider)
const init3 = async () => {
    try {

        // let nonce;
        // for(let i=0;i<5;i++){
        let productid = 6112179;
        const provider = new Provider(privateKey, infuraUrl);
        const web3 = await new Web3(provider, { timeout: 3000000 });
        const networkId = await web3.eth.net.getId();
        console.log("networkid->", networkId);

        let nonce = parseInt(await web3.eth.getTransactionCount(address));
        nonce = nonce++;
        console.log(nonce);
        const myContract = new web3.eth.Contract(
            MyContract.abi,
            MyContract.networks[networkId].address
        );
        // let nonce = 479;
        let res1 = await myContract.methods.getdata().send({ from: address, nonce: nonce++ }).catch((err) => {
            console.log("error here" + err);
        });
        // .then((result1) => {

        //                         console.log("result get data-> " + JSON.stringify(result1));
        //                       })

        // for (let i = 1; i < 10; i++) {

        // console.log("this is nonce",nonce);

        await web3.eth.signTransaction({
            from: address,

            // nonce: nonce++,
        }).then(console.log).catch(console.log);
        console.log("fine sign transaction");

        await myContract.methods.set_newbatch_product(120, parseInt(productid), "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo").send({
            from: address,
            nonce: nonce++

            //     // }, function(error, transactionHash){ console.log("error 1",error); console.log("transactionHash1 ",transactionHash); })
            //     // .on('error', function(error){ console.log("error2",error); })
            //     // .on('transactionHash', function(transactionHash){ console.log("transactionhash3",transactionHash) });

            //     // .on('receipt', function(receipt){
            //     //    console.log("receipt4",receipt.contractAddress) // contains the new contract address
            //     // })
            //     // .on('confirmation', function(confirmationNumber, receipt){ console.log("confirm5",confirmationNumber); console.log("receipt5",receipt); })
            //     // .then(function(newContractInstance){
            //     //     console.log("newcontractinstance",JSON.stringify(newContractInstance)) // instance with the new contract address
            //     // });
            //     //.send({
            //     //       from: address,
            //     //       gas:500000,
            //     //       nonce: nonce++})
        }).then((result) => {
            (async () => {
                try {
                    // let res1 = await myContract.methods.getdata().send({from:address}).then((result1) => {

                    //         //             console.log("result get data-> " + JSON.stringify(result1));
                    //         //           }).catch((err) => {
                    //         //             console.log("error here" + err);
                    //         //           });
                    let res = await myContract.methods.gettdata().call().then((resp) => {
                        console.log(resp);
                    }).catch(error => {
                        console.log("error->", error);
                    });
                } catch (e) {
                    console.log(e);
                }

            })();
            //     // console.log("fine method  transaction",JSON.stringify(result));
            //     console.log("result here..." + JSON.stringify(result));
            //     //     console.log("result->"+JSON.stringify(result));
            // }).catch(error => {
            //     console.log("error->", error.message);
        }).catch(error => {
            console.log("error->", error);
        });
        // (async () => {
        //     let res1 = await myContract.methods.getdata().send({from:address}).then((result1) => {

        //         console.log("result get data-> " + JSON.stringify(result1));
        //       }).catch((err) => {
        //         console.log("error here" + err);
        //       });

        //     //   console.log(res1);
        // // console.log(`Transaction hash: ${receiptt.transactionHash}`);
        // // console.log(`New data value: ${await myContract.methods.get_product_details(30050).call()}`);
        // })();
        // //   console.log(`Old data value: ${await myContract.methods.get_product_details(123456780).call()}`);
        // const receipt = await myContract.methods.set_warranty(12345).send({ from: address }).then(result => {
        //     (async () => {
        //     console.log(result);
        //     console.log(`Transaction hash: ${receipt.transactionHash}`);
        //     console.log(`New data value: ${await myContract.methods.get_product_details(12345).call()}`);
        //     })();
        // }).catch(error => { 
        //     //console.log("error->", error) 
        // });
        // console.log(i);
        productid + 120;
        // console.log( "forr loop incremented -> "+i);
        // }
        console.log("khatam");
    } catch (e) {
        console.log("last error", e)
    }
}

async function getTotalsold(nonce2) {
    if (address != null) {
  
  
        const provider = new Provider(privateKey, infuraUrl);
        const web3 = await new Web3(provider, { timeout: 3000000 });
        
    //   const id = await web3.eth.net.getId();
      // const deployednetwork = mycontract.networks[id];
      const networkId = await web3.eth.net.getId();

      const contract = new web3.eth.Contract(
        MyContract.abi,
        MyContract.networks[networkId].address
      );
      const addresses = web3.eth.getAccounts();
  
  
      let res1 = await contract.methods.getdata().send({ from: address,nonce:nonce2  }).then((res) => {
        console.log("result here" + JSON.stringify(res))}).catch((err) => {
        console.log("error here" + JSON.stringify(err));
    });      // console.log("total sold products are: " + result1);
      // const data= await web3.eth.getData().call();
      return await res1;
  
  
  
  
    } else {
      return "Please Connect Your Metamask";
    }
  
  
  }



const init4 = async (productidd,totalno,j) => {
    let i;
    let loop = 1;
    // let productidd = 987878976;
    const provider = new Provider(privateKey, infuraUrl);
    const web3 = new Web3(provider, { timeout: 3000000 });
    const networkId = await web3.eth.net.getId();
    console.log("networkid->", networkId);
    web3.eth.handleRevert = true;
    // txCount = 
    i=i++;
    let nonce =  j;
    console.log(" first nounce " + nonce);
    const myContract = new web3.eth.Contract(
        MyContract.abi,
        MyContract.networks[networkId].address
    );
    web3.eth.getGasPrice()
        .then(res => { gas = res; });
    console.log("number of loop " + loop);

    let currgas = 999999;
    //
    currgas = currgas * 1.5

    console.log("gas here.!->", web3.eth.getTransactionCount(address, 'pending'));
    const addresses = web3.eth.getAccounts();
    console.log(addresses);
    web3.eth.signTransaction({
        from: address,
        // gasPrice: Math.floor(currgas),
        nonce: nonce,
    }).then(console.log).catch(console.log);

    web3.eth.handleRevert = true;
    i=i++;
    let nonce1 = j+1;
    console.log(" nounce for set new batch product" + nonce1);


    const result = await myContract.methods.set_newbatch_product(totalno, parseInt(productidd), "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo").send({
        from: address,
        // nonce: nonce1
        // gasPrice: Math.floor(currgas),
        //  gas: Math.floor(9999999),
        // gasPrice: 22000000000
    }).then((result1) => {
        console.log("set new batch result ->" + JSON.stringify(result1));
        (async () => {

            let res = await myContract.methods.gettdata().call().then((resp) => {

                unsuccessvar = resp['0'];
                successvar = resp['1'];
                console.log("list of successfull data is here-> " + successvar + "\n");

                for (let i = 0; i < resp['1'].length; i++) {
                    let enc = String(encrypt(resp['1'][i], "Rushikesh"));
                    let manu_date = Math.floor(Date.now() / 1000);
                    let urllink = "https://www.autic.com/productid=" + enc;
                    // console.log(urllink);
                    var qr_png = qr.image(urllink, { type: 'png' });
                    qr_png.pipe(require('fs').createWriteStream('assets/Images/qrimages/' + enc + '.png'));
                    var png_string = qr.imageSync(urllink, { type: 'png' });
                    let query = `INSERT INTO product_details( user_id, product_id, bname,rcurrent,soperation,manu_date,period,color,msize,material,coo,qr_encrypt,dname) VALUES ('${"req.session.uid"}','${resp['1'][i]}','${"bname"}','${"rcurrent"}','${"soperation"}','${"manu_date"}','${"period"}','${"color"}','${"msize"}','${"material"}','${"coo"}','${enc}','${"did"}')`;
                    database.query(query, function (error, data) {
                        // console.log("product id inserted in database" + resp['1'][i]);
                        // console.log("database error" + error);
                        // console.log("database success" + data);

                    });

                    // response.send([resp['0']]);

                    // console.log(query);

                }
                // response.write('loop ' + i + " on going.!");
                (async () => {
                    // i=i+2;
                    let nonce2 =  j+2;
                    // console.log(" nounce for sign transaction2 " + nonce2);
                    console.log(JSON.stringify(await getTotalsold(nonce2)));

                    // web3.eth.signTransaction({
                    //     from: address,
                    //     nonce: nonce2,
                    //     // gasPrice: Math.floor(currgas * 1.5),

                    // }).then(result => { console.log("sign transaction 2 result here.!",result) }).catch(err => { console.log("sign transaction 2 error here.!->", err) });

                    // i=i++;
                    // let nonce3 =  j+3;
                    // console.log(" nounce for last transaction " + nonce3);

                    // let res1 = await myContract.methods.getdata().send({
                    //     from: address,
                    //     // nonce: nonce3
                
                    // }).then((result1) => {
                        
                    //     console.log("result get data-> " + JSON.stringify(result1));
                    //     return;
                    // }).catch((err) => {
                    //     console.log("error here" + JSON.stringify(err));
                    // });

                })();


                // response.json({
                //   addbatchproduct: "addbatchproduct",
                //   unsuccessful: unsuccessvar,
                //   successful: successvar,
                // });

            });
            return;
        })();






    }).catch((err) => {
        console.log("add batch product error here.!->" + JSON.stringify(err));
        // unsuccess++;
        // response.json({
        //   addbatchproduct: "addbatchproduct",
        //   unsuccessful: err,
        //   successful: err,
        // });
    });
    return;

    //   toooo = toooo - 120;
    // loop++;
    // productidd = productidd + 120
    //   console.log("remaining products after loop are " + toooo);
    // console.log("i value at last " + i);
    //   response.write('loop ' + i + " completed.!");
    //  response.json({
    //         addbatchproduct: "addbatchproduct",
    //         unsuccessful: unsuccessvar,
    //         successful: successvar,
    //       });

    // setTimeout(function(){console.log('timeout started for three milliseconds..!')},3000);



}
//   }
// })();


// }
const init5 = async () => {
    let j=881;
    let productidd=43648635;
    let totalno=500;
for(let i=0;i<5;i++){
    // (async()=>{

        console.log("number of loop",i+1);
      await init4(productidd,120,j);
    //   if(totalno>120){
          totalno=totalno-120;
          productidd=productidd+120;
          j=j+4;
    //   }else{
    //       break;
    //   }
    // })();
}

console.log("completed here.!!!");
return;
}

init1();


//////////////////////////////////////
const init6 = async (totalno,productidd) => {
    const web3 = new Web3(infuraUrl);
    const networkId = await web3.eth.net.getId();
    const myContract = new web3.eth.Contract(
        MyContract.abi,
        MyContract.networks[networkId].address
    );
console.log("first group ok.....");
    const tx = myContract.methods.set_newbatch_product(totalno, parseInt(productidd), "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo");
    console.log("second group ok.....");

    const gas = await tx.estimateGas({ from: address });
    const gasPrice = await web3.eth.getGasPrice();
    const data = tx.encodeABI();
    const nonce = (await web3.eth.getTransactionCount(address)+1);

    console.log("Gas ....."+ gas);
    console.log("gasPrice....."+ gasPrice);
    console.log("nonce....."+nonce);
    console.log("data.....",data);
    // console.log("third group ok.....");
    console.log("third group ok.....");

    const signedTx = await web3.eth.accounts.signTransaction(
        {
            to: myContract.options.address,
            data,
            gas,
            gasPrice,
            nonce,
            chainId: networkId
        },
        privateKey
    ).then(res=>{console.log("result  ",res)}).catch(err=>{console.log("error here.!",err)});
    console.log("fourth group ok.....");

    // console.log(`Old data value: ${await myContract.methods.data().call()}`);
    // const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
    // console.log(`Transaction hash: ${receipt.transactionHash}`);
    console.log("fifth group ok.....");
    const ress=await myContract.methods.gettdata().call();
    console.log(`Old data value: `,JSON.stringify(ress));

    // console.log(`New data value: ${await myContract.methods.data().call()}`);
}
////////////////////////////////////// 182415156


const init7 = async (totalno,productidd) => {
    const web3 = new Web3(infuraUrl);
    const networkId = await web3.eth.net.getId();
    const myContract = new web3.eth.Contract(
      MyContract.abi,
      MyContract.networks[networkId].address
    );
    web3.eth.accounts.wallet.add(privateKey);
  
    const tx = myContract.methods.set_newbatch_product(totalno, parseInt(productidd), "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo");
    const gas = 999999;
    // await tx.estimateGas({from: address});
    const gasPrice = 9999999;
    //await web3.eth.getGasPrice();
    const data = tx.encodeABI();
    const nonce = await web3.eth.getTransactionCount(address)+6;
    console.log(nonce);
    const txData = {
      from: address,
      to: myContract.options.address,
      data: data,
      gas,
      gasPrice,
      nonce, 
    //   chain: 'ropsten',
    //   hardfork: 'london' 
     
    };
    const ress=await myContract.methods.gettdata().call();
    console.log(`Old data value: `,JSON.stringify(ress));
    // console.log(`Old data value: ${await myContract.methods.data().call()}`);
    const receipt = await web3.eth.sendTransaction(txData).on('transactionHash', function(hash){
       console.log("hash here.! ",hash);
    })
    .on('receipt', function(receipt){
        console.log("receipt here.! ",receipt);
        // ...
    })
    .on('confirmation', function(confirmationNumber, receipt){ 
        console.log("confirmation here.!",confirmationNumber);
        console.log("receipt here.!",receipt);
        
         })
    .on('error', function(error){
        console.log("error here.!",error) }); 
    // })
    console.log("fourth group ok.....");;
    // console.log(`Transaction hash: ${receipt.transactionHash}`);
    // console.log(`New data value: ${await myContract.methods.data().call()}`);
  }
  



// init7(120,252415455);

// init3();
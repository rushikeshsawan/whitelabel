const web3js = require('web3')
// let Tx = require('ethereumjs-tx').Transaction
// //  Tx = new Tx(Tx, {chain:'ropsten', hardfork: 'petersburg'})

let web3 = new web3js(
  new web3js.providers.HttpProvider(
    "https://ropsten.infura.io/v3/cecc686c7c684ee981dd2961d36d084c"
  )
)
// const pvt="4925f96bd005d94c76b3646593aba2615f4b65b197160bdf96ce9a586d41067e";

const account = '0x8e8Ef3E7D09D1fE0683f9B782860Bb00e41DE660'; //Your account address
// const privateKey = Buffer.from(pvt, 'hex');
const contractAddress = '0x25450a840B504cb1Bde85E61463e446F8890dDAB'; // Deployed manually
const abi =  [
    {
      "inputs": [],
      "name": "get_total_unsold_product",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "_unsold",
          "type": "uint256"
        }
      ],
      "name": "set_total_unsold_product",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "_sold",
          "type": "uint256"
        }
      ],
      "name": "set_total_sold_product",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "get_total_sold_product",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "productid",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "_name",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "Rated_Current",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "switch_operation",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "warr_period",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "color",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "module_size",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "material",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "coo",
          "type": "string"
        }
      ],
      "name": "set_new_product",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "to",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "productid",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "_name",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "Rated_Current",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "switch_operation",
          "type": "string"
        },
        {
          "internalType": "uint256",
          "name": "warr_period",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "color",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "module_size",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "material",
          "type": "string"
        },
        {
          "internalType": "string",
          "name": "coo",
          "type": "string"
        }
      ],
      "name": "set_newbatch_product",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "getdata",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [],
      "name": "gettdata",
      "outputs": [
        {
          "internalType": "uint256[]",
          "name": "",
          "type": "uint256[]"
        },
        {
          "internalType": "uint256[]",
          "name": "",
          "type": "uint256[]"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "num",
          "type": "uint256"
        }
      ],
      "name": "getttdata",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        },
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "productid",
          "type": "uint256"
        }
      ],
      "name": "set_warranty",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "id",
          "type": "uint256"
        }
      ],
      "name": "get_product_details",
      "outputs": [
        {
          "components": [
            {
              "internalType": "string",
              "name": "brand",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "Rated_Current",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "Switch_Operation",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "Module_Size",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "material",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "Country_of_Origin",
              "type": "string"
            },
            {
              "internalType": "string",
              "name": "color",
              "type": "string"
            },
            {
              "internalType": "uint256",
              "name": "manu_date",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "warranty_start",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "warranty_end",
              "type": "uint256"
            },
            {
              "internalType": "uint256",
              "name": "warr_period",
              "type": "uint256"
            }
          ],
          "internalType": "struct SimpleStorage.data",
          "name": "",
          "type": "tuple"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    }
  ];
const Contract = new web3.eth.Contract(abi, contractAddress, {
  from: account,
  
});

// const contractFunction = contract.methods.set_newbatch_product(120, parseInt(38436535), "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo");
// // Here you can call your contract functions

// const functionAbi = contractFunction.encodeABI();

// let estimatedGas;
// let nonce;

// console.log("Getting gas estimate");

// contractFunction.estimateGas({from: account}).then((gasAmount) => {
//   estimatedGas = gasAmount.toString(16);

//   console.log("Estimated gas: " + estimatedGas);

//   web3.eth.getTransactionCount(account).then(_nonce => {
//     nonce = _nonce.toString(16);

//     console.log("Nonce: " + nonce);
//     const txParams = {
//       gasPrice: 100000,
//       gasLimit: 3000000,
//       to: contractAddress,
//       data: functionAbi,
//       from: account,
//       nonce: '0x' + nonce
//     };

//     const tx = new Tx(txParams);
//     tx.sign(privateKey); // Transaction Signing here

//     const serializedTx = tx.serialize();

//     web3.eth.sendSignedTransaction('0x' + serializedTx.toString('hex')).on('receipt', receipt => {
//       console.log(receipt);
//     })
//   });
// });


// const init4 = async (productidd,totalno,j) => {
    (async)
    let j=881;
    let productidd=54534534;
    let totalno=500;
for(let i=0;i<5;i++){
    console.log("number of loop",i+1);
   
const Tx = require('ethereumjs-tx').Transaction;
const contractFunction = Contract.methods.set_newbatch_product(120, parseInt(38436535), "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo");

 var rawTransaction = {
  "from": "0x8e8Ef3E7D09D1fE0683f9B782860Bb00e41DE660",
  "gasPrice": web3js.utils.toHex(20 * 1e9),
  "gasLimit": web3js.utils.toHex(9999999),
  "to": "0x25450a840B504cb1Bde85E61463e446F8890dDAB",
  "value": "0x0",
  "data":  Contract.methods.set_newbatch_product(totalno, parseInt(productidd), "bname", "rcurrent", "soperation", parseInt(12), "color", "msize", "material", "coo").encodeABI(),
}

  var privateKey ='4925f96bd005d94c76b3646593aba2615f4b65b197160bdf96ce9a586d41067e'

  web3.eth.accounts.signTransaction(rawTransaction, privateKey)
  .then(function(value){
    (async()=>{
        web3.eth.sendSignedTransaction(value.rawTransaction)
          .then(function(response){
            console.log("response:" + JSON.stringify(response, null, ' '));
          })

    })
    })
}
// await init4(productidd,120,j);
//   if(totalno>120){
      totalno=totalno-120;
      productidd=productidd+120;
      j=j+4;
// }


    const init5 = async () => {
        let j=881;
        let productidd=54534534;
        let totalno=500;
    for(let i=0;i<5;i++){
        // (async()=>{
    
            console.log("number of loop",i+1);
          await init4(productidd,120,j);
        //   if(totalno>120){
              totalno=totalno-120;
              productidd=productidd+120;
              j=j+4;
        //   }else{
        //       break;
        //   }
        // })();
    }
    
    console.log("completed here.!!!");
    return;
    }
    // init5();
